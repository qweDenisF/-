﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIT
{
    public class VisitingObject
    {
        public string fullName, service, time, phone, ID, price;

    }
}
